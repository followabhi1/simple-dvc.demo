Create a new env

activate env

pip install requirements.txt file



updated this file
